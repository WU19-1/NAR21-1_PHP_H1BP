Use WUUX

-- 1
SELECT u.UserID,
CASE 
	WHEN u.UserGender = 'Male' THEN 'Mr. ' + u.Username
	ELSE 'Mrs. ' + u.Username
END AS 'Usernames'
,ph.PlaylistName
FROM WUUX.dbo.PlaylistHeader ph 
JOIN WUUX.dbo.Users u ON u.UserID = ph.UserID
WHERE u.UserID LIKE '[A-z]%'
ORDER BY Username

-- 2 -- 
SELECT MusicName,MusicDuration,'Music Release Date' = CONVERT(VARCHAR,MusicReleaseDate,106)
FROM Music m
JOIN ArtistDetail ad ON ad.MusicID = m.MusicID
JOIN Artist a ON a.ArtistID = ad.ArtistID
WHERE m.MusicGenre = 'KPOP' AND DATEPART(QUARTER,MusicReleaseDate) = 3
GROUP BY MusicName,MusicDuration,MusicReleaseDate
HAVING COUNT(ArtistName) BETWEEN 2 AND 4
UNION
SELECT MusicName,MusicDuration, 'Music Release Date' = CONVERT(VARCHAR,MusicReleaseDate,106)
FROM Music m
JOIN ArtistDetail ad ON ad.MusicID = m.MusicID
JOIN Artist a ON a.ArtistID = ad.ArtistID
WHERE m.MusicGenre = 'Hip Hop' AND DATEPART(QUARTER,MusicReleaseDate) = 3
GROUP BY MusicName,MusicDuration,MusicReleaseDate
HAVING COUNT(ArtistName) BETWEEN 2 AND 4

-- 3 -- 
SELECT PlaylistName,'Total Music in Playlist' = CONCAT(COUNT(m.MusicID),' count(s)')
FROM PlaylistHeader ph
JOIN PlaylistDetail pd ON pd.PlaylistID = ph.PlaylistID
JOIN Music m ON m.MusicID = pd.MusicID
WHERE YEAR(CreatedAt) BETWEEN 2010 AND 2020
GROUP BY PlaylistName,CreatedAt
HAVING COUNT(m.MusicID) = (
	SELECT MAX(T1.counter)
	FROM (
		SELECT PlaylistName,COUNT(m.MusicID) as 'counter'
		FROM PlaylistHeader ph
		JOIN PlaylistDetail pd ON pd.PlaylistID = ph.PlaylistID
		JOIN Music m ON m.MusicID = pd.MusicID
		GROUP BY PlaylistName) 
	as T1
)

-- 4 --
BEGIN TRANSACTION
UPDATE Music
SET MusicName += ' [Exclusive]'
FROM (
	SELECT m.musicname,COUNT(ph.playlistname) as 'counter'
	FROM Music m
	JOIN PlaylistDetail pd on m.musicid = pd.musicid
	JOIN PlaylistHeader ph on ph.playlistid = pd.playlistid
	GROUP BY m.musicname
) as t2 JOIN Music m ON m.musicname = t2.musicname
WHERE t2.counter >= 5

-- ini untuk ngecek nomor 4 MR --
SELECT * FROM Music
WHERE MusicName LIKE '%Exclusive%'
-- ini untuk ngecek nomor 4 MR --

ROLLBACK

-- 5 --
BEGIN TRANSACTION
DELETE PlaylistDetail
FROM PlaylistDetail pd
JOIN Music m ON pd.MusicID = m.MusicID
JOIN PlaylistHeader ph on pd.PlaylistID = ph.PlaylistID
WHERE MusicName = 'As I Wished'
AND PlaylistName LIKE '% % %'
--WHERE m.MusicID IN (SELECT MusicID FROM Music WHERE MusicName = 'As I Wished')

-- 6 --
CREATE LOGIN SE WITH PASSWORD = 'wuux',DEFAULT_DATABASE= WUUX
GO
CREATE USER SE FOR LOGIN SE
GO
GRANT SELECT TO SE
GO
DENY UPDATE,DELETE,INSERT TO SE

-- 7 --
DECLARE @i int
SET @i = 11
DECLARE @j int
DECLARE @k int
SET @j = 0
SET @k = 0
WHILE(@j != @i)
BEGIN
	DECLARE @row varchar(max)
	SET @row = ''
	SET @k = 0
	WHILE (@k != @i)
	BEGIN
		IF (@j != 0 AND @j != @i-1 AND @k != 0 AND @k != @i-1 AND @k != @j AND @k != @i-@j-1)
		BEGIN
			SET @row += ' '
		END
		ELSE
		BEGIN
			SET @row += '#'
		END
		SET @k += 1
	END
	PRINT(@row)
	SET @j += 1
END

-- 8 --
SELECT MusicName,
(
	SELECT STUFF([name],1,1,'') as artist_name
	FROM 
	(
		SELECT DISTINCT ',' + a.ArtistName
		FROM Artist a
		JOIN ArtistDetail ad ON
		a.ArtistID = ad.ArtistID
		WHERE ad.MusicID = m.MusicID
		FOR XML PATH('')
	) q([name])
) as Artists
FROM Music m
GROUP BY MusicName,MusicID

-- 9 --
SELECT MusicName,'Music Duration' = CONCAT(MusicDuration/60,':',MusicDuration%60)
FROM (
	SELECT TOP 2 *
	FROM Music
	WHERE MusicGenre = 'Hip Hop'
	ORDER BY MusicDuration DESC
) AS HipHop
UNION
SELECT MusicName,'Music Duration' = CONCAT(MusicDuration/60,':',MusicDuration%60)
FROM (
	SELECT TOP 2 *
	FROM Music
	WHERE MusicGenre = 'KPOP'
	ORDER BY MusicDuration DESC
) AS Kpop
ORDER BY MusicName

-- 10 -- 
BEGIN TRAN
INSERT INTO PlaylistHeader
SELECT NEWID(),'FD1C0E33-74D8-4D19-A8AF-FF6A0A05A72C','PlaylistName' = LEFT(value,CHARINDEX(';',value)-1),
'CreatedAt' = CAST (RIGHT(value,(LEN(VALUE) -CHARINDEX(';',value)) ) as datetime)
FROM
string_split(
	'Hotel Del Luna OST;02/13/2014|Love;10/01/2011|Fall in love from the first kiss OST;12/26/2017|TPA all night;07/16/2017|Koreksian all night;01/02/2012|Casemaking all night;11/28/2018|RIG all night;02/13/2011|Core training all night;10/24/2013',
	'|'
)

ROLLBACK

-- 11 --
-- Add column LastPlayed (with datetime data type) into PlaylistHeader table
BEGIN TRAN
ALTER TABLE PlaylistHeader
ADD LastPlayed DATETIME NULL

ROLLBACK

-- 12 --
-- Delete the oldest playlist's music
BEGIN TRAN
DELETE PlaylistDetail
FROM PlaylistDetail pd JOIN PlaylistHeader ph
ON pd.PlaylistID = ph.PlaylistID
WHERE ph.PlaylistID IN (
	SELECT TOP(1) PlaylistID
	FROM PlaylistHeader
	WHERE DATEDIFF(YEAR,CreatedAt,GETDATE()) > 15
	ORDER BY CreatedAt ASC
)

ROLLBACK

-- nge cek --
SELECT PlaylistDetail.PlaylistID,MusicName,CreatedAt
FROM PlaylistDetail
JOIN Music ON Music.MusicID = PlaylistDetail.MusicID
JOIN PlaylistHeader ON PlaylistHeader.PlaylistID = PlaylistDetail.PlaylistID
WHERE
PlaylistHeader.PlaylistID IN (
	SELECT TOP(1) PlaylistID
	FROM PlaylistHeader
	WHERE DATEDIFF(YEAR,CreatedAt,GETDATE()) > 15
	ORDER BY CreatedAt ASC
)
ORDER BY CreatedAt ASC
-- nge cek --

-- 13 -- Rp. 2000 per hari
SELECT q.Username,'Debt' = 'Rp. ' + CAST(SUM(q.days) * 2000 as varchar)
FROM (
	SELECT u.Username ,(DATEDIFF(DAY,ph.CreatedAt,'2020/07/01') * z.[total music]) as 'days'
	FROM Users u
	JOIN PlaylistHeader ph
	ON ph.UserID = u.UserID
	JOIN (
		SELECT PlaylistID, 'total music' = COUNT(MusicID)
		FROM PlaylistDetail pd
		GROUP BY PlaylistID
	)as z ON z.PlaylistID = ph.PlaylistID
) q
GROUP BY q.Username

-- 14 --
SELECT 
	CASE
		WHEN Username LIKE '% %' THEN LEFT(Username,1) + SUBSTRING(Username,CHARINDEX(' ',Username)+1,1)
		ELSE LEFT(Username,1) + UPPER(RIGHT(Username,1))
	END AS Initial,
	Username
FROM Users
WHERE MONTH(UserDOB) BETWEEN 3 AND 6 AND UserGender = 'Male'

-- 15 --
BEGIN TRAN
ALTER TABLE Users
ADD UserEmail varchar(100)
ALTER TABLE Users
ADD CONSTRAINT EmailCheck CHECK(UserEmail LIKE '%@%')

-- 16 --
SELECT
	TABLE_NAME,(
		SELECT STUFF((
			SELECT ',' + COLUMN_NAME
			FROM INFORMATION_SCHEMA.COLUMNS y
			WHERE x.TABLE_NAME = y.TABLE_NAME
			FOR XML PATH('')
		),1,1,'')
	) as [Columns]
FROM INFORMATION_SCHEMA.COLUMNS x
GROUP BY TABLE_NAME

-- 17 --
SELECT PlaylistName
FROM PlaylistHeader ph
JOIN PlaylistDetail pd ON ph.PlaylistID = pd.PlaylistID
JOIN Music m ON m.MusicID = pd.MusicID
WHERE m.MusicID IN (
	SELECT MusicID
	FROM ArtistDetail ad
	JOIN Artist a ON ad.ArtistID = a.ArtistID
	WHERE YEAR(a.ArtistJoinDate) % 2 = 0
	GROUP BY MusicID
	HAVING COUNT (MusicID) > 2
) 
-- 18 --
SELECT DISTINCT 'Mr. / Mrs.' + REVERSE(SUBSTRING(REVERSE(a.ArtistName),1,CHARINDEX(' ',REVERSE(a.ArtistName)) - 1)) 
FROM Artist a
JOIN ArtistDetail ad ON ad.ArtistID = a.ArtistID
WHERE ArtistName LIKE '% % %' AND a.ArtistID IN (
	SELECT ArtistID
	FROM ArtistDetail
	WHERE MusicID IN (
		SELECT MusicID
		FROM Music
		WHERE MusicName LIKE 'Ending Scene'
	)
)

-- 19 --
ALTER TABLE Users
DROP COLUMN UserEmail

-- 20 --
DROP DATABASE WUUX

def main():
	a = ''
	for i in range(0,10):
		for j in range (0,10):
			a += '*'
	print(a)
	

main()